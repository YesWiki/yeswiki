<?php
$port = $_SERVER["SERVER_PORT"];

if ($_SERVER["REMOTE_ADDR"]=="127.0.0.1") {
	if ($_GET["execute"]) {
		$updir = "..";
		$ZMWSdir = $updir ."\ZMWS";
		if (strpos($_SERVER["DOCUMENT_ROOT"], "_vhosts.zmwsc") !== FALSE) $updir .= "\..\..";
		switch ($_GET["execute"]) {
			case "heidisql": 
				chdir($ZMWSdir);
				exec("HeidiSQL\heidisql.exe");
				header("Location: ". $_SERVER["PHP_SELF"] );
				exit();
				break;
			
			case "dostats": 
				chdir($ZMWSdir);
				exec("dostats.bat");
				header("Location: /stats");
				exit();
				break;
			case "opendocroot":
				exec("start explorer \"".$_SERVER["DOCUMENT_ROOT"]."\"");
				break;
			case "phpinfo":
				phpinfo();
				exit();
			case "stopall":
				chdir($ZMWSdir);
				exec("mysql_stop.bat");
				header("Location: /_stopServer.zmwsc");
				exit();
				break;
			case "mysqlstart":
				chdir($ZMWSdir);
				if (version_compare(PHP_VERSION, "5.0.0") == -1) {
					$WShell = com_load("WScript.Shell");
				} else {
					$WShell = new COM("WScript.Shell");
				}
				if ($WShell) {
					$WShell->Run("mysql_start.bat", 0, false);
				} else {
					die("Impossible d'initialiser COM");
				}
				break;
			case "mysqlstop":
				chdir($ZMWSdir);
				exec("mysql_stop.bat");
				sleep(10);
				header("Location: ". $_SERVER["PHP_SELF"] );
				break;
		}
		header("Location: ".$_SERVER["HTTP_REFERER"]."#".$_GET["execute"]);
	}
}
?>
<html>
	<head>
		<title>Framakey WebApps</title>
		  <style type="text/css">
body {
font-family: Arial,Helvetica,sans-serif;
background-color: #d5d5ff;
}
  </style>

	</head>
	<body>

		<ul class="menu_sub">
		<?php
		$rep=opendir('.');
		$bAuMoinsUnRepertoire = false;
		while ($file = readdir($rep)) {
		   if($file != '..' && $file !='.' && $file !='') {
			   if (is_dir($file)){
				   if (FALSE === strstr ($file, ".zmwsc") &&
					   $file<>"css" &&
					   $file<>"protected" &&
					   $file<>"AppInfo" &&
					   $file<>"stats" &&
					   $file<>"data" &&
					   $file<>"icons") {
					   $bAuMoinsUnRepertoire = true;
					   print("<li><span class='linker'><a href='$file/'>$file</a></span>");
				   }
			   }
			}
		}
		if ($bAuMoinsUnRepertoire == false) {
		   print("<li><span >");
		   print("-&nbsp; R&eacute;pertoire vide &nbsp;-");
		   print("</span>");
		}
		closedir($rep);
		clearstatcache();
		?>
		</ul>
		<ul>
		<li><?php
		$docroot = str_replace("/", "\\", $_SERVER["DOCUMENT_ROOT"]);
		echo "<a class=\"fichiers\" href=\"".$_SERVER["PHP_SELF"]."?execute=opendocroot\">$docroot</a>\n";
		?></li>
		
		<li><a href="<?php echo $_SERVER["PHP_SELF"]."?execute=phpinfo"; ?>">phpinfo</a></li>

		<li>MySQL</li>
		<ul>
			<li>Status : 
			<?php
				echo $link = @mysql_connect("localhost", "root", "") ? "Started" : "Stopped";
			?>
			</li>
			<li><a href="<?php echo $_SERVER['PHP_SELF']. '?execute=mysqlstart' ?>">Start</a></li>
			<li><a href="<?php echo $_SERVER['PHP_SELF']. '?execute=mysqlstop' ?>">Stop</a></li>
			<li><a href="http://127.0.0.2/eskuel/">Eskuel</a></li>
			<li><a href="?execute=heidisql">HeidiSQL</a></li>
		
		</ul>
		
		<li><a href="<?php echo $_SERVER['PHP_SELF']. '?execute=stopall' ?>">Stop MySQL & ZMWS</a></li>

		</ul>
	<body>
</html>