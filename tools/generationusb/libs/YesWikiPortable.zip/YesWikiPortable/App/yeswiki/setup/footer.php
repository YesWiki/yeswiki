<?php
if (!defined('WIKINI_VERSION'))
{
	die ("acc&egrave;s direct interdit");
}

ob_end_flush();
?></body>
</html>
