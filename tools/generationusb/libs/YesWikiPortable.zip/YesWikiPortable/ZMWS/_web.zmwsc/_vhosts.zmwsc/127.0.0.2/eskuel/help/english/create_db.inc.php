<?php
$help = '<FONT size=+0><B>Create a new database</B></FONT>
	<BR><BR>From here you can create a new database
	<BR>You won\'t be able to create a new database if you host does not allow you to. You could not create a database if you have fill in the "Only database" field in the configuration you use.
	<BR>You can not create a database which the name contain quotation marks (")';
?>