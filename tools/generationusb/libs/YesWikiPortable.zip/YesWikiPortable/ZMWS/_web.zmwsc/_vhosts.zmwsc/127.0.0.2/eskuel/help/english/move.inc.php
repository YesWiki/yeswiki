<?php
$help = '<FONT size=+0><B>Move a table</B></FONT>
	<BR><BR>
	Allow you to move the current table to another one.
	<BR>You can move the table into the current database or in an other one if you have not pick the \'Only the database\' option in your current configuration.
	<BR><Font color="#FF0000">The new name can not contain any quotation mark (")</font>';
?>