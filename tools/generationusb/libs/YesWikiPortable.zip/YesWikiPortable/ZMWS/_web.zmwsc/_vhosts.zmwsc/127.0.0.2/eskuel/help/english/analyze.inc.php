<?php
$help = '<FONT size=+0><B>Analyze a table</B></FONT>
	<BR><BR>
	Analyze and stock the keys distribution for the current table. This feature only works with <B>MyISAM</B> and <B>BDB</B> tables.';
?>