<?php
$help = '<FONT size=+0><B>Optimize a table</B></FONT>
	<BR><BR>
	Optimize the current table.
	This feature can be used when you\'ve deleted a lot of records. It makes a defragmentation of your datas an re-use lost spaces.';
?>