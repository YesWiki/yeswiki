<?php
$font = 'face="Verdana, Arial, Helvetica" size="1"';

$bgcolor 		= '#E7E7E7';
$table_bg 		= '#FFFFFF';
$titre_bg 		= '#CCCCCC';
$titre_img 		= '';
$logo_align 	= '';
$titre_font 	= '#002850';
$bordercolor 	= '#000000';
$vlink 			= $titre_font;
$link 			= $titre_font;
$text 			= '#323232';
$alink 			= $titre_font;
$trou_bg		= '#002850';
$trou_font 		= '#FFFFFF';
$trou_border 	= '#000000';
$bosse_bg 		= $trou_bg;
$bosse_font 	= $trou_font;
$bosse_border 	= $trou_border;
$pick_bg 		= $table_bg;
$pick_border 	= $titre_font;
$use_other_img 	= 0;
$tpl_type 		= 0;
?>