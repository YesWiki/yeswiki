<?php
$help = '<FONT size=+0><B>Delete a database</B></FONT>
		<BR>If you click, eskuel will show you how many tables and records will be losts.
		<BR>If you choose "yes" the database will be deleted and <font color="#FF0000">you won\'t be able to get it back</font>.';
?>