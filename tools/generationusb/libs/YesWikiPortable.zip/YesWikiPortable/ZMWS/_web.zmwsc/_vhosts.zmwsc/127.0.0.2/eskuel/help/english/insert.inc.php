<?php
$help = '<FONT size=+0><B>Add a new record</B></FONT>
	<BR><BR>
	This part allow you to add a new record in your current table.
	<BR>The drop-down boxes allow you to choose the functions you want to apply
	to the value you\'ve typed.';
?>