<?php
$help = '<FONT size=+0><B>Add a field in a table</B></FONT>
	<BR><BR>
	You can with this option, add one or more field into the current table.
	<BR>Enter the number of fields you\'ll need, and their positions :
	at the beginning of the table, at the end of the table or after a specified field.
	<BR><BR>
	Then fill in the creation form :
	<BR>- Key type
	<BR>- Name of the field
	<BR>- Type of the field
	<BR>- Length of the field
	<BR>- Attributes (BINARY, UNSIGNED ou UNSIGNED ZEROFILL)
	<BR>- Is the field can be null ?
	<BR>- The default value of this field
	<BR>- Is it supposed to be auto incremented
	<BR><BR>You\'ll find a link at the bottom of this form which can help you about the different field types.';
?>