<?php
$help = '<FONT size=+0><B>Copy a table</B></FONT>
	<BR><BR>
	Allow you to copy the current table.
	<BR>You can copy it into the current database or in an other one (depends on you settings).
	<BR>You have to choose if you want to copy the table structure <B>and/or</B> the datas.';
?>