<?php
$help = '<FONT size=+0><B>Rename a table</B></FONT>
	<BR><BR>
	Allow you to rename any table
	<BR>
	<font color="#FF0000">The new name can not contain any quotation mark (")</font>';
?>