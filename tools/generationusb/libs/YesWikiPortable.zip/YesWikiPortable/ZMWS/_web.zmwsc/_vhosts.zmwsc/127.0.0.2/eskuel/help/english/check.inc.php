<?php
$help = '<FONT size=+0><B>Check a table</B></FONT>
	<BR><BR>
	Check a table and detect errors. Only works with <B>MyISAM</B> and <B>InnoDB</B> tables.';
?>