<?php
$help = '<FONT size=+0><B>Repair a table</B></FONT>
	<BR><BR>
	Repair a table.
	This feature only works with <B>MyISAM</B> tables.';
?>