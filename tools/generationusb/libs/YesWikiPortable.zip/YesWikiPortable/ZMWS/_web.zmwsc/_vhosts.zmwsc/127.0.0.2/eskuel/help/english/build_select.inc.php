<?php
$help = '<FONT size=+0><B>Select in a table</B></FONT>
	<BR><BR>
	You can display on or more records depending on options.
	<BR>
	First, choose the fields  to use, in the top left form.
	<BR><BR>
	Then you can :
	<BR>- Choose a search criterion in the "Clause Where" field.
	<BR>OR
	<BR>- Choose an approximation criterion with the fileds in the bottom
	<BR>Enter an element to search in front of the field you want to search in and select if you want to sort the results ascending or descending.
	<BR>For larger searches, use the % character.';
?>