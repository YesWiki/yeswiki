<?php

### eskuel's configuration file
### Configuration number 0
$confDB['0']['name'] = 'localhost';
$confDB['0']['host'] = '127.0.0.1:3306';
$confDB['0']['user'] = 'root';
$confDB['0']['password'] = '';
$confDB['0']['db'] = '';
$confDB['0']['tpl'] = '';


$conf['defaultPerRequest'] = '50';
$conf['defaultConf'] = '0';
$conf['defaultTxt'] = 'francais.inc.php';
$conf['tipsOfTheDay'] = '0';
$conf['siteUrl'] = 'http://';
$conf['showMysqlState'] = '1';
$conf['showMysqlVars'] = '1';
$conf['showMysqlProcess'] = '1';
$conf['reduceBlob'] = '50';

?>