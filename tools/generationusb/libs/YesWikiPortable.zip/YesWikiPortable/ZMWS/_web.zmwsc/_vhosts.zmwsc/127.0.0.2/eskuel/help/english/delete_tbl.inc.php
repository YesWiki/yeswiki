<?php
$help = '<FONT size=+0><B>Delete a table</B></FONT>
	<BR><BR>
	Delete the current table. This feature will how you the number of records to be deleted.
	<BR><font color="#FF0000">The table is definitely deleted</font>';
?>