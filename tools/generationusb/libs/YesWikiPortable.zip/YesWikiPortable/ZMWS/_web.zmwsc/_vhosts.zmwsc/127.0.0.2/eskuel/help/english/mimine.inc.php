<?php
$help = '<FONT size=+0><B>Manual query</B></FONT>
		<BR><BR>This feature display a little popup which allow you to type manually your query and manage your query bookmarks.
		<BR>You can not use this feature if you have not choose any database.
		<BR>You can hide the popup by clicking on the red cross at the right top of it.';
?>