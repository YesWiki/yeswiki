<?php

// Template : professionnel

$font = 'face="Verdana, Arial, Helvetica" size="1"';
$bgcolor = '#E7E7E7';
$table_bg = '#FFFFFF';
$titre_bg = '#CCCCCC';
$titre_font = '#002850';
$bordercolor = '#000000';
$vlink = '#002850';
$link = '#002850';
$text = '#323232';
$alink = '#002850';
$trou_bg = '#002850';
$trou_border = '#000000';
$trou_font = '#FFFFFF';
$bosse_bg = '#002850';
$bosse_font = '#FFFFFF';
$bosse_border = '#000000';
$pick_bg = '#FFFFFF';
$pick_border = '#002850';
$use_other_img = 0;
$tpl_type = 1;


?>