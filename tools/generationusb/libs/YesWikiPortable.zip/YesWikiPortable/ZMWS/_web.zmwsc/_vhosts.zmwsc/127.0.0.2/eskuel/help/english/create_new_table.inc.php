<?php
$help = '<FONT size=+0><B>Create a new table</B></FONT>
		<BR><BR>
		You can create a new table in the current database from here.
		<BR>This operation is in two times :
		<BR><BR>
		<B>1 - Name and number of fields :</B>
		<BR>Enter the name of the table and the number of fields you need.
		<BR><BR><B>2 - Fields settings :</B>
		<BR><BR>Choose :
		<BR>- The key type (if needed)
		<BR>- The field name (can not contain any quotation mark (") )
		<BR>- The data type (a summary is available at the end of this creation page)
		<BR>- If you allow the null datas
		<BR>- The length of the field (some type of datas need a length)
		<BR>- Its attributes (BINARY, UNSIGNED ou UNSIGNED ZEROFILL)
		<BR>- Its default value.
		<BR>- If it must be auto-incremented
		<BR><BR>You can also add a comment to this new table';
?>
