<?php
$help = '<FONT size=+0><B>Empty a table</B></FONT>
	<BR><BR>
	Empty the current table. This feature delete all the records of a table but do not alter the structure of this table
	<BR><font color="#FF0000">All the records are definitely deleted</font>.';
?>