<?php
$help = '<FONT size=+0><B>Change / add table comment</B></FONT>
	<BR><BR>
	You can add or modify a <B>60 characters\' length comment</B>.';
?>