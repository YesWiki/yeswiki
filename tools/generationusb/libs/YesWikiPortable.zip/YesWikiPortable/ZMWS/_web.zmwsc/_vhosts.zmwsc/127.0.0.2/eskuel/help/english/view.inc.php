<?php
$help = '<FONT size=+0><B>Display the content of a table</B></FONT>
		<BR><BR>
        With this option you can display the content of a table as you like.
        <BR>At the top you find the SQL query used to display the selection at the screen.
        <BR>There is, just below, a link to dump (save) the records returned by the sql query.
        <BR>You could find, too, different information about the table you are using : number of records displayed, your position in the table, number of total records...
        <BR><BR>
        <FORM>
        You\'ll be able to use a navigation bar which allow you to :
        <BR>- Go to the beginning of the table ( <INPUT type="button" value="&lt;&lt;" class="bosses"> )
        <BR>- Display previous records ( <INPUT type="button" value="&lt;" class="bosses"> )
        <BR>- Display next records ( <INPUT type="button" value="&gt;" class="bosses"> )
        <BR>- Go to the last records ( <INPUT type="button" value="&gt;&gt;" class="bosses"> )
        <BR><BR>
        To navigate in the table you can enter the position of the first record to be display, and the number of records you would like to display per page.
        <BR><BR>
        You can also modifiy or delete some records with the two links in front of each record.
        ';
?>