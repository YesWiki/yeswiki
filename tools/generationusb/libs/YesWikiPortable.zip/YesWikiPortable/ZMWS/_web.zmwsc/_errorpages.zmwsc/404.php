<?php
for ($i=0; $i<100; ++$i)
	echo "404 Not Found !";
?>